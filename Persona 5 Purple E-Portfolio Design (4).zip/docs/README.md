# Hamza Saif Udeen — E-Portfolio

Static site. Nine pages, no build step, no dependencies.

## Publish on GitHub Pages
1. Create a repo (e.g. `eportfolio`) on github.com — Public.
2. Upload every file in this folder to the repo root (drag and drop works).
3. Repo → **Settings** → **Pages** → Source: **Deploy from a branch**, Branch: **main**, Folder: **/ (root)** → Save.
4. Wait ~1 minute. Your site is live at `https://<username>.github.io/eportfolio/`.

## Photos
Upload your images into the same repo (an `img/` folder is tidy), then replace the striped
placeholder blocks with:
`<img src="img/yourphoto.jpg" alt="" style="width:100%;height:100%;object-fit:cover;display:block">`

## Embedding into Google Sites
Insert → Embed → **By URL** → paste the page URL, e.g.
`https://<username>.github.io/eportfolio/projects.html`
